<p>
<label for="wall_title">Title: <input  name="wall_title" type="text" value="<?php echo $title; ?>" /></label>
			
<input type="hidden" id="wall_submit" name="wall_submit" value="1" />
</p>